# AgriScan AI — Advanced Crop Health Screening

A modularized next-step prototype for the PlantVillage-based model you trained in Colab.

## Features included
- Single-image leaf screening with image quality/context heuristic
- Top-five prediction confidence gauges
- Guidance cards split into cultural/organic, chemical caution, and prevention
- Batch scan with CSV export
- SQLite persistence for scans, garden plants, and reminders
- Searchable scan history and export
- PDF scan reports
- Best-effort Grad-CAM-style attention map when model layers match the expected MobileNetV2 architecture
- Responsive dark-green UI

## Important limitations
- The photo check is a heuristic, not a trained TensorFlow.js leaf detector.
- Grad-CAM is an attention visualization, not a disease spot bounding box or segmentation mask.
- Reminders are stored in the app database; there are no push notifications.
- Live weather, location permission, and outbreak feeds are not connected.
- The classifier is only as good as its training data. Confirm disease and treatment with local agricultural expertise.

## Required model files
By default, the app expects:
- `/content/agriscan_ai/agriscan_model.keras`
- `/content/agriscan_ai/class_labels.json`

The class labels must be the exact order used by the model during training.

## Run in Google Colab
1. Ensure the two model files above exist.
2. Upload `app.py` into Colab's `/content` directory.
3. Run in a new code cell:

```python
%pip install -r /content/requirements.txt
%run /content/app.py
```

If `requirements.txt` was uploaded to another location, change its path accordingly. If you use the single app file only, install dependencies using:

```python
%pip install gradio pandas reportlab pillow
```

TensorFlow must already be installed and compatible with your Colab runtime.

## Persistent storage note
SQLite persists while the Colab runtime filesystem survives. Colab files can disappear when the runtime resets. For reliable long-term data, use a persistent disk or a managed database in deployment.

## Local / hosted run
Install requirements, set `AGRISCAN_MODEL`, `AGRISCAN_LABELS`, and optionally `AGRISCAN_HOME`, then run `python app.py`.
For a hosting platform that injects `PORT`, the app uses that port. For a non-public run, set `GRADIO_SHARE=false`.
